from guizero import App
app = App()
app.info("Info", "This is a guizero app")
app.error("Error", "Try and keep these out your code...")
app.warn("Warning", "These are helpful to alert users")
app.display()